---
title: 'Today''s newspapers'
media_order: press.jpg
articles:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
folders:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
---

Newspapers regard other newspapers as their rivals. But the market for information is now global, not just national or regional.

The new technical companies who seek out information on the Internet and deliver it to people on screen are becoming bigger rivals to the newspapers than the broadcasters. And they are offering advertisers more targeted audiences.

Here are the old guard, the new upstarts and the youngsters who are doing hyperlocal news for their town or village.