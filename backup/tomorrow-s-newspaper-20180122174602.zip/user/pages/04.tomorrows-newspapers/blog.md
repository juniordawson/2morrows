---
title: 'Tomorrows newspapers'

articles:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
folders:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
---

Content here

