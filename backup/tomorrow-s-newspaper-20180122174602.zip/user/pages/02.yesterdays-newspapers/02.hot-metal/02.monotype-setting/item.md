---
title: 'Monotype setting'
---

The Monotype was a more efficient typesetter than the Linotype. The operator simply typed out the copy and the machine produced punched paper tape. This tape was then fed into the Monotype casting machine which churned out justified lines of type automatically.  
The Monotype system was not used by Fleet Street newspapers. The people who had learned to use a Linotype in a long, hard apprenticeship, did not want to see a simpler machine which any typist could use.  
And managements who had invested thousands in Linotype machines saw little point in investing thousands more in Monotype machines and then trying to renegotiate all their agreements with the Linotype men.