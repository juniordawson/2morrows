---
title: Random
---

The random was the clearing house for the composing room. People would bring type and the sub-editors' copy from which it was set to the random. 
The people who worked on the random printed proofs of the type they received in their galleys and collated the various takes of type into complete stories.  
From the random, type went to a page on the stone and the sub-editor's copy with the galley proof went to the readers. I cannot remember whether random people ferried the stuff around, or people went to the random to pick it up, but I'm sure the various union chapels had strict rules about that.