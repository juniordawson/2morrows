---
title: Deadlines
---

Being late is the ultimate crime on a newspaper. Printing thousands of copies takes time and then they then have to be driven to hundreds of corner shops and stations before the first commuters wander in at 6am.  
If one paper is late, the early crowd will take a rival's paper and ciculation will dip.  
When that happens, there will be an inquest to find somebody to blame and, if necessary, sack to make sure it never ever happens again.  
In the days of hot metal, journalists always blamed the composing room - the 'f---ing inkies' for not seting or making up type quickly enough.  
Now there is no composing room, they blame the people at the print plants for not making their plates quickly enough or   
not running their presses fast enough.  
As modern printing plants are so efficient they employ only half a dozen people, journalists are running out of other people to blame.