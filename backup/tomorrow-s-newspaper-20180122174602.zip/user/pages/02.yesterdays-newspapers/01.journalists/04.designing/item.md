---
title: Designing
---

Newspaper pages are designed by artistes who strive constantly for new ways of displaying the news.  
No they aren't. Newspaper pages are designed to a rigid formula so the readers won't be frightened by any art school nonsense.  
In the old days, designers scribbled their page designs on layout pads and wrote catchlines to show where stories, pictures and adverts went. Copies of these layouts went to the back bench, the chief sub, the composing room and the stone sub.  
Hot metal typesetting was designed to go in regular columns. Type in irregular widths, or running around a picture was so hard to produce, that page layouts were usually kept simple.  Now, pages are initiated on screen and type can be set in any shape, at any angle and overlapping a picture. Some newspaper pages are as good as the glossy magazines.  
Editors still insist that they look something like yesterday's paper. Design changes are done very carefully.