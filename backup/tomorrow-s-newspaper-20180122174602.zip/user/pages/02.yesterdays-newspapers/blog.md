---
title: 'Yesterday''s newspapers'
media_order: Double_Octuple_Newspaper_Press.jpg
articles:
    items: '@self.children'
    order:
        by: date
        dir: asc
    limit: 10
    pagination: true
folders:
    items: '@self.children'
    order:
        by: date
        dir: asc
    limit: 10
    pagination: true
---

I was lucky enough to work for the Daily Mail from the days of hot metal until 2010 and to be involved in the technical revolution.  
Yesterday's newspapers looks back at how journalists worked in the old days and how technology has helped them, And how the old technology worked when the ‘inkies' produced the paper.