---
title: home
visible: false
content:
    items: '@root.children'
    order:
        by: default
        dir: desc
    limit: 10
    pagination: true
---

Welcome to Tomorrow's newspapers.

Newspapers are drinking in the Last Chance Saloon. It is not closing time yet, but it soon will be.  

Their readers are dying out. Youngsters get their news on their phones and tablets. Advertisers, who used to pay for the journalists, are going to phones and tablets because that is where the customers are. 

Disruption is all around. And newspapers hate change. Young journalists have always learned from experienced journalists: This is how we get stories. This is how we display stories.  

In more enlightened businesses, the young are telling the old: This is how we should be doing things now.  

Newspapers work on a daily or weekly cycle. Digital news is there in seconds.  

The clock is ticking . . .