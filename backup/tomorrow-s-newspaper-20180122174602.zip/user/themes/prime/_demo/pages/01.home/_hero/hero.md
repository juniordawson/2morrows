---
title: Hero
---

#Welcome to PRIME
A Clean, Modern, Responsive Theme for [**Grav**](https://getgrav.org/)
<br>
Built with the [**Primitive CSS Framework**](http://taniarascia.github.io/primitive/)

<a href="https://github.com/CollinDaugherty/grav-theme-prime/archive/master.zip" class="button accent-button"><i class="fa fa-download"></i>  Download PRIME</a>
<a href="https://github.com/CollinDaugherty/grav-theme-prime/" class="button white-button">View on <i class="fa fa-github"></i> Github</a>
