---
title: Home
content:
  items: '@self.modular'
  order:
    custom:
      - _hero
      - _features
      - _services1
      - _services2
      - _services3
      - _blogfeed
      - _testmonials
---