---
title: 'Recent Articles'
content:
    items:
        '@page.children': /blog
    limit: 3
---

