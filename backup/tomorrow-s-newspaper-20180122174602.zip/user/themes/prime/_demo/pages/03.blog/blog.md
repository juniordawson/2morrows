---
content:
    items: '@self.children'
    pagination: true
    limit: 10
---

