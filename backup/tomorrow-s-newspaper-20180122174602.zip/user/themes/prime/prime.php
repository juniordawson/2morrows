<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Prime extends Theme
{
    // Access plugin events in this class
}
